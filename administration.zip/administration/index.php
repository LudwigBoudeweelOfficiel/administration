<!DOCTYPE html>
<html>
<head>
  <title>Page de connexion</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    
    .container {
      width: 300px;
      margin: 0 auto;
      margin-top: 100px;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	  overflow:hidden;
	  animation: animation1 0.5s linear;
      animation-fill-mode: both;
    }
	
	@keyframes animation1 {
    from {
      width: 10px;
      height: 10px;
    }
    to {
      width: 300px;
      height: 10px;
    }
  }

  @keyframes animation2 {
    from {
      width: 300px;
      height: 10px;
    }
    to {
      height: 300px;
      width: 300px;
    }
  }

    .logo {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .logo img {
      width: 100px;
      height: 100%;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
    }
    
    .form-group input {
      width: 100%;
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }
    
    .form-group button {
      width: 100%;
      padding: 8px;
      border: none;
      background-color: #4caf50;
      color: #fff;
      font-weight: bold;
      cursor: pointer;
      border-radius: 3px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">
      <img src="img/logo.png" alt="Logo">
    </div>
    <form action="traitement.php" method="GET">
      <div class="form-group">
        <label for="username">Nom d'utilisateur</label>
        <input type="text" id="username" name="user" placeholder="Entrez votre nom d'utilisateur">
      </div>
      <div class="form-group">
        <label for="password">Mot de passe</label>
        <input type="password" id="password" name="pwd" placeholder="Entrez votre mot de passe">
      </div>
      <div class="form-group">
        <button type="submit">Se connecter</button>
      </div>
    </form>
  </div>
  
  <script>
  const element = document.querySelector('.container');

  // Écoute de l'événement 'animationend' pour la première animation
  element.addEventListener('animationend', () => {
    // Appliquer la deuxième animation
    element.style.animation = 'animation2 1s ease-in-out forwards';
  });
</script>
</body>
</html>
