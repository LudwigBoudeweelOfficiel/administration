<!DOCTYPE html>
<?php
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=Administration', 'root','', array(
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")); 
	$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

// Recherche des données concernant l'utilisateur tentant de se connecter
$menu = $bdd->query('SELECT * FROM menu');
?>
<html>
<head>
  <title>Liste des devis</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    
    .container {
      width: 600px;
      margin: 0 auto;
      margin-top: 100px;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    h1 {
      text-align: center;
    }
    
    .pdf-list {
      list-style-type: none;
      padding: 0;
    }
    
    .pdf-list-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
    }
    
    .pdf-list-item img {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
    
    .pdf-list-item a {
      text-decoration: none;
      color: #333;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Générer un devis</h1>
	<form action="generer_devis.php" method="GET">
	  <!-- Ligne 1 -->
	  <label>Libellé :</label>
	  <input type="text" name="lib1" placeholder="Clavier"/>
	  <label>Qté :</label>
	  <input type="number" name="qte1" placeholder="2" style="width:40px"/>
	  <label>PRIX :</label>
	  <input type="text" name="prix1" placeholder="2" style="width:40px"/>
	  <label>Lien :</label>
	  <input type="text" name="url1" placeholder="ldlc"/>
	  <hr>
	  <!-- Ligne 2 -->
	  <label>Libellé :</label>
	  <input type="text" name="lib2" placeholder="Clavier"/>
	  <label>Qté :</label>
	  <input type="number" name="qte2" placeholder="2" style="width:40px"/>
	  <label>PRIX :</label>
	  <input type="text" name="prix2" placeholder="2" style="width:40px"/>
	  <label>Lien :</label>
	  <input type="text" name="url2" placeholder="ldlc"/>
	  <hr>
	  <!-- Ligne 3 -->
	  <label>Libellé :</label>
	  <input type="text" name="lib3" placeholder="Clavier"/>
	  <label>Qté :</label>
	  <input type="number" name="qte3" placeholder="2" style="width:40px"/>
	  <label>PRIX :</label>
	  <input type="text" name="prix3" placeholder="2" style="width:40px"/>
	  <label>Lien :</label>
	  <input type="text" name="url3" placeholder="ldlc"/>
	  <hr>
	  <!-- Ligne 4 -->
	  <label>Libellé :</label>
	  <input type="text" name="lib4" placeholder="Clavier"/>
	  <label>Qté :</label>
	  <input type="number" name="qte4" placeholder="2" style="width:40px"/>
	  <label>PRIX :</label>
	  <input type="text" name="prix4" placeholder="2" style="width:40px"/>
	  <label>Lien :</label>
	  <input type="text" name="url4" placeholder="ldlc"/>
	  <hr>
	  <!-- Ligne 5 -->
	  <label>Libellé :</label>
	  <input type="text" name="lib5" placeholder="Clavier"/>
	  <label>Qté :</label>
	  <input type="number" name="qte5" placeholder="2" style="width:40px"/>
	  <label>PRIX :</label>
	  <input type="text" name="prix5" placeholder="2" style="width:40px"/>
	  <label>Lien :</label>
	  <input type="text" name="url5" placeholder="ldlc"/>
	  
	  
	  <input type="submit" value="Générer le devis"/>
	</form>
  </div>
</body>
</html>
