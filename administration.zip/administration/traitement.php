<?php
ini_set("display_errors",0);
session_start();
$_SESSION['login'];
$user = $_GET['user'];
$mdp =  $_GET['pwd'];




// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=Administration', 'root','', array(
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")); 
	$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

// Recherche des données concernant l'utilisateur tentant de se connecter
$data = $bdd->query('SELECT * FROM logs WHERE Login = "'.$user.'"');
$ddata = $data->fetch();

if($ddata['Mdp']==$mdp){
	echo "<h2>Redirection en cours...</h2>";
	$_SESSION['login']==$ddata['Identifiant'];
	?>
		<script>window.location.href="home.php";</script>
	<?php
}else{
	
}
?>