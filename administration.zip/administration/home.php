<!-- On affiche la page -->
<html>
<head>
  <title>Blocs centrés</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    
    .container {
      width: 600px;
      margin: 0 auto;
      margin-top: 100px;
      display: flex;
      justify-content: center;
	  animation: animation1 0.5s linear;
      animation-fill-mode: both;
	  animation-delay:0.5s;
    }
    
    .row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
    }
    
    .block {
      width: 200px;
      height: 200px;
	  margin:20px;
      background-color: #fff;
      border: 1px solid #ccc;
      border-radius: 5px;
      display: flex;
      justify-content: center;
      align-items: center;
	  text-align:center;
    }
	
	.block:hover{
		cursor:pointer;
	}
	
	@keyframes animation1 {
    from {
      opacity:0;
	  margin-top:90px;
    }
    to {
      opacity:1;
	  margin-top:100px;
    }
  }

  @keyframes animation2 {
    from {
      width: 300px;
      height: 10px;
    }
    to {
      height: 300px;
      width: 300px;
    }
  }
  </style>
  <style>
#snackbar {
  visibility: hidden;
  min-width: 250px;
  margin-left: -125px;
  background-color: #333;
  color: #fff;
  text-align: center;
  border-radius: 2px;
  padding: 16px;
  position: fixed;
  z-index: 1;
  left: 50%;
  top: 30px;
  font-size: 17px;
}

#snackbar.show {
  visibility: visible;
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
  from {top: 0; opacity: 0;} 
  to {top: 30px; opacity: 1;}
}

@keyframes fadein {
  from {top: 0; opacity: 0;}
  to {top: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {top: 30px; opacity: 1;} 
  to {top: 0; opacity: 0;}
}

@keyframes fadeout {
  from {top: 30px; opacity: 1;}
  to {top: 0; opacity: 0;}
}
</style>
</head>
<body>

  <!-- The actual snackbar -->
<div id="snackbar">Ca arrive bientôt !</div>
<script>
function myFunction() {
  var x = document.getElementById("snackbar");
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
}
</script>
<script>
  const element = document.querySelector('.container');

  // Écoute de l'événement 'animationend' pour la première animation
  element.addEventListener('animationend', () => {
    // Appliquer la deuxième animation
    element.style.animation = 'animation2 1s ease-in-out forwards';
  });
</script>

  <div class="container">
    <div class="row">
      <div class="block" onclick="window.location.href='devis.php'">
        <p>DEVIS</p>
      </div>
      <div class="block" onclick="myFunction()">
        <p>PRÊTS</p>
      </div>
    </div>
    <div class="row">
      <div class="block">
        <p>RESERVATIONS SALLE INFO</p>
      </div>
      <div class="block" onclick="window.location.href='menu.php'">
        <p>MENU DE LA CANTINE</p>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="block" onclick="window.location.href='g_devis.php'">
        <p>Générer devis</p>
      </div>
      <div class="block">
        <p>Bloc 2</p>
      </div>
    </div>
    <div class="row">
      <div class="block">
        <p>Bloc 3</p>
      </div>
      <div class="block">
        <p>Bloc 4</p>
      </div>
    </div>
  </div>
</body>
</html>