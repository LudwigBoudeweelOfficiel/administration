<!DOCTYPE html>
<?php
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=Administration', 'root','', array(
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")); 
	$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

// Recherche des données concernant l'utilisateur tentant de se connecter
$menu = $bdd->query('SELECT * FROM menu');
?>
<html>
<head>
  <title>Liste des devis</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    
    .container {
      width: 600px;
      margin: 0 auto;
      margin-top: 100px;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    h1 {
      text-align: center;
    }
    
    .pdf-list {
      list-style-type: none;
      padding: 0;
    }
    
    .pdf-list-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
    }
    
    .pdf-list-item img {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
    
    .pdf-list-item a {
      text-decoration: none;
      color: #333;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Liste des menus disponibles</h1>
	<button onclick="window.location.href='add_menu.php'">Ajouter un menu</button>
    <ul class="pdf-list">
	  <?php
	  while($dmenu = $menu->fetch()){
		  ?>
		  
		  <li class="pdf-list-item">
             <img src="icon/<?php echo $dmenu['ext']?>.png" alt="PDF">
             <a href="uploads/menu/<?php echo $dmenu['NomFichier']?>" target="_blank"><?php echo $dmenu['NomFichier']?> - <?php echo $dmenu['datep']?></a>
			 <a href="mailto:intendant.0590198v@ac-lille.fr?subject=Devis :<?php echo $dmenu['NomFichier']?>"><img src="icon/send.png" alt="PDF"></a>
          </li>
		  
		  <?php
	  }
	  ?>
      
    </ul>
  </div>
</body>
</html>
