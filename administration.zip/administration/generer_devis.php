<?php
require('fpdf/fpdf.php');
$date = date( "d/m/Y");

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'Devis du '.$date);

// Date du devis
$pdf->SetFont('Arial','',12);
$pdf->Ln(10);
$date = date( "d/m/Y");
$pdf->Ln(20);
$total = 0;


//En tête du tableau
$pdf->SetFont('Arial','B',14);
$pdf->Cell(80,6,"LIBELLE",1);
$pdf->Cell(15,6,"QTE",1);
$pdf->Cell(25,6,"PRIX",1);
$pdf->Cell(55,6,"LIEN",1);
$pdf->Ln();
$pdf->SetFont('Arial','',12);


//Ligne 1
if($_GET['lib1']){
$pdf->SetFont('Arial','',12);
$pdf->Cell(80,6,$_GET['lib1'],1);
$pdf->Cell(15,6,"x".$_GET['qte1'],1);
$pdf->Cell(25,6,$_GET['prix1']."e",1);
$pdf->Cell(55,6,$_GET['url1'],1);
$pdf->Ln();

// Ajouter le prix de la ligne 1 au total
$total += $_GET['prix1'];
}
//Ligne 2
if($_GET['lib2']){
$pdf->SetFont('Arial','',12);
$pdf->Cell(80,6,$_GET['lib2'],1);
$pdf->Cell(15,6,"x".$_GET['qte2'],1);
$pdf->Cell(25,6,$_GET['prix2']."e",1);
$pdf->Cell(55,6,$_GET['url2'],1);
$pdf->Ln();
$total += $_GET['prix2'];
}



//Prix total
$pdf->SetFillColor(0,0,0);
$pdf->SetFont('Arial','',12);
$pdf->Cell(95,6,"TOTAL",1);
$pdf->Cell(25,6,$total."e",1);
$pdf->Ln();
$total += $_GET['prix2'];



    // Positionnement à 1,5 cm du bas
    $pdf->SetY(-40);
    // Police Arial italique 8
    $pdf->SetFont('Arial','I',8);
    // Numéro de page
    $pdf->Cell(0,10,'Page '.$pdf->PageNo().'/{nb}',0,0,'C');



// Ligne du devis
$pdf->SetFont('Arial','',14);
$pdf->Output();
$pdf->Close();
?>