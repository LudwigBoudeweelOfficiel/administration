<?php
// Connexion à la base de données
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=Administration', 'root','', array(
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")); 
	$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

// Vérifier si un fichier a été uploadé
if(isset($_FILES['file'])) {
    $file = $_FILES['file'];

    // Emplacement de destination pour sauvegarder le fichier
    $destination = 'uploads/menu/' . $file['name'];
	
	// Date de dernière modif
	$dateModification = filemtime($destination);
	
	// Récupérer l'extension du fichier
    $extension = pathinfo($destination, PATHINFO_EXTENSION);

    // Déplacer le fichier vers l'emplacement de destination
    if(move_uploaded_file($file['tmp_name'], $destination)) {
        echo 'Le fichier a été uploadé avec succès.';
		// INSERER DANS LA BASE DE DONNEES
		$insert = $bdd->query('INSERT INTO menu(NomFichier,datep, ext) VALUES("'.$file['name'].'","'.$dateModification.'","'.$extension.'")');
		$dinsert = $insert->fetch();
		?>
		<script>window.location.href='menu.php';</script>
		<?php
    } else {
        echo 'Une erreur s\'est produite lors de l\'upload du fichier.';
    }
}
?>
