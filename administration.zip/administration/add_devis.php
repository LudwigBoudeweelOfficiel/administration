<!DOCTYPE html>
<html>
<head>
  <title>Uploader un fichier</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    
    .container {
      width: 400px;
      margin: 0 auto;
      margin-top: 100px;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    h1 {
      text-align: center;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
    }
    
    .form-group input[type="file"] {
      display: none;
    }
    
    .form-group .file-input-label {
      display: inline-block;
      padding: 8px 12px;
      border: 1px solid #ccc;
      border-radius: 3px;
      background-color: #f2f2f2;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Uploader un devis</h1>
    <form enctype="multipart/form-data" method="post" action="upload.php">
      <div class="form-group">
        <label for="file">Sélectionner un fichier</label>
        <input type="file" id="file" name="file">
        <label class="file-input-label" for="file">Choisir un fichier</label>
      </div>
      <div class="form-group">
        <button type="submit">Upload</button>
      </div>
    </form>
  </div>
</body>
</html>
